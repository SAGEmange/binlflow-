def test_imports():
    import binlflow
    assert hasattr(binlflow, "StateTensor") is False  # exported via module import side-effects
