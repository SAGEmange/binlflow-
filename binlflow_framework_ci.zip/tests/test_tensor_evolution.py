import torch
from binlflow.states import NUM_STATES
from binlflow.tensor import GridShape, StateTensor
from binlflow.hamiltonian import LocalHamiltonian, Couplings
from binlflow.lindblad import LindbladPack
from binlflow.evolution import MultiTemporalEvolver

def test_step_shapes():
    shape = GridShape(2,2,1,1,1,1)
    psi = StateTensor(shape).psi
    torch.manual_seed(0)
    psi = (torch.randn_like(psi) + 1j*torch.randn_like(psi))*0.05
    psi = psi / torch.sqrt(torch.sum(torch.abs(psi)**2, dim=-1, keepdim=True))

    H = LocalHamiltonian().build(NUM_STATES)
    evo = MultiTemporalEvolver(H_local=H, couplings=Couplings(), lindblad=LindbladPack())
    out = evo.step(psi)
    assert out.shape == psi.shape
