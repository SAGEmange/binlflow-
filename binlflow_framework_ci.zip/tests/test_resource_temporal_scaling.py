import torch
from binlflow.resource import temporal_scaling

def test_temporal_scaling_positive():
    x = torch.ones((2,3,5), dtype=torch.complex64)*0.2
    y = temporal_scaling(x)
    assert (y > 0).all()
