import torch

def toy_syndrome(alpha):
    probs = torch.real(alpha.conj()*alpha)
    return (probs > 0.25).to(torch.int32)

def toy_recovery(alpha, syndrome, phase=-0.5j):
    phase_vec = torch.ones_like(alpha)
    phase_val = torch.exp(torch.ones_like(alpha)*phase)
    phase_vec = torch.where(syndrome.bool(), phase_val, phase_vec)
    return alpha * phase_vec
