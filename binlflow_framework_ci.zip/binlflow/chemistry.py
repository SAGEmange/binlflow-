import torch

def reaction_diffusion(A, alpha, D=0.05, k0=0.01, lam=0.001, dt=1e-2):
    prob = torch.real(alpha.conj()*alpha)
    mod = (prob[...,0:1] * 1.0 + prob[...,1:2] * 0.5 + prob[...,2:3] * 0.2).sum(dim=-1, keepdim=True)
    lap = -6*A
    for d in range(3):
        lap = lap + torch.roll(A, 1, dims=d) + torch.roll(A, -1, dims=d)
    dA = D*lap + k0*mod*A - lam*A
    return A + dt*dA
