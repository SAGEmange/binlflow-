import torch

def coherence(rho_total, rho_ideal, eps=1e-9):
    num = torch.real(torch.sum(rho_total.conj()*rho_ideal))
    den = torch.sqrt(torch.sum(torch.abs(rho_total)**2)*torch.sum(torch.abs(rho_ideal)**2) + eps)
    return num/den

def multi_temporal_efficiency(work, energy, eps=1e-9):
    return work / (energy + eps)
