from dataclasses import dataclass
import torch
from .interactions import neighbor_average

def i_times(x):
    return 1j * x

@dataclass
class MultiTemporalEvolver:
    H_local: torch.Tensor
    couplings: object
    lindblad: object
    hbar: float = 1.0

    def step(self, psi, dt1=1e-2, dt2=5e-2, dt3=1e-1):
        Hpsi = torch.tensordot(psi, self.H_local.T, dims=([-1],[0]))
        dpsi_H = -i_times(Hpsi) / self.hbar

        neigh = neighbor_average(psi)
        dpsi_J = self.couplings.pairwise_term(neigh)
        dpsi_V = self.couplings.three_body_term(psi, neigh)

        dpsi_L = self.lindblad.dissipator(psi)

        dpsi_t1 = dpsi_H + 1.5*dpsi_J + 0.2*dpsi_V + 0.5*dpsi_L
        dpsi_t2 = 0.7*dpsi_H + 1.0*dpsi_J + 0.3*dpsi_V + 0.7*dpsi_L
        dpsi_t3 = 0.4*dpsi_H + 0.6*dpsi_J + 0.4*dpsi_V + 1.0*dpsi_L

        psi = psi + dt1*dpsi_t1 + dt2*dpsi_t2 + dt3*dpsi_t3
        return psi
