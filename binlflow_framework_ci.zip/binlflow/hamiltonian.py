from dataclasses import dataclass
import torch

@dataclass
class LocalHamiltonian:
    diag_strength: float = 1.0
    mix_strength: float = 0.1

    def build(self, num_states: int, device="cpu", dtype=torch.complex64):
        H = torch.zeros((num_states, num_states), dtype=dtype, device=device)
        for i in range(num_states):
            H[i, i] = (i+1) * self.diag_strength
        mix = self.mix_strength / max(1, (num_states - 1))
        for i in range(num_states):
            for j in range(num_states):
                if i != j:
                    H[i, j] = mix
        return H

@dataclass
class Couplings:
    J: float = 0.05
    V: float = 0.01

    def pairwise_term(self, psi_neighbors):
        return self.J * psi_neighbors

    def three_body_term(self, psi_local, psi_neighbors):
        return self.V * psi_local * torch.abs(psi_neighbors)**2
