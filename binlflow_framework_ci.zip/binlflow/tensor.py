from dataclasses import dataclass
import torch
from .states import NUM_STATES

@dataclass
class GridShape:
    X: int
    Y: int
    Z: int
    T1: int
    T2: int
    T3: int

class StateTensor:
    """
    Ψ(x,y,z,t1,t2,t3, s), s in {F,S,L,P,T}, complex amplitudes
    shape: (X, Y, Z, T1, T2, T3, S)
    """
    def __init__(self, shape: GridShape, device="cpu", dtype=torch.complex64):
        self.shape = shape
        self.device = device
        self.dtype = dtype
        self.psi = torch.zeros(
            (shape.X, shape.Y, shape.Z, shape.T1, shape.T2, shape.T3, NUM_STATES),
            dtype=dtype, device=device
        )

    def normalize(self, eps: float = 1e-9):
        norm = torch.sqrt(torch.sum(torch.abs(self.psi)**2, dim=-1, keepdim=True) + eps)
        self.psi = self.psi / norm
        return self

    def probabilities(self):
        return torch.real(self.psi.conj() * self.psi)

    def copy(self):
        other = StateTensor(self.shape, self.device, self.dtype)
        other.psi = self.psi.clone()
        return other
