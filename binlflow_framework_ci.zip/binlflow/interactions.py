import torch

def neighbor_average(psi, spatial_dims=(0,1,2)):
    rolled = []
    for dim in spatial_dims:
        rolled.append(torch.roll(psi, 1, dims=dim))
        rolled.append(torch.roll(psi, -1, dims=dim))
    avg = sum(rolled) / len(rolled)
    return avg
