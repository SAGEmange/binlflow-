import torch

def optimal_load_balancing(psis, H_load_diag=1.0, lam=0.1):
    S = psis.shape[-1]
    device = psis.device
    H = torch.arange(1, S+1, device=device, dtype=torch.float32)
    expect = torch.real((psis.conj() * psis * H).sum(dim=-1))
    term1 = (expect**2).mean()
    flat = psis.reshape(-1, S)
    gram = (flat.conj() @ flat.T).abs()
    term2 = (gram - torch.diag(torch.diag(gram))).mean()
    return term1 + lam*term2

def temporal_scaling(alpha, R0=1.0, betas=None):
    if betas is None:
        betas = torch.ones(alpha.shape[-1], device=alpha.device) * 0.1
    probs = torch.real(alpha.conj()*alpha)
    factor = torch.prod(1.0 + betas * probs, dim=-1, keepdim=True)
    return R0 * factor
