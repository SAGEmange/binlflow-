from dataclasses import dataclass
import torch

@dataclass
class LindbladPack:
    dephase_rate: float = 0.02
    damp_rate: float = 0.01

    def dissipator(self, psi):
        return -(self.dephase_rate + self.damp_rate) * psi
