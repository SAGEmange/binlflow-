# Contributing

1. Create a virtualenv: `python -m venv .venv && source .venv/bin/activate`
2. Install deps: `pip install -r requirements.txt -r requirements-dev.txt`
3. Enable hooks: `pre-commit install`
4. Run tests: `pytest -q`

Please open PRs against `main` and ensure CI passes.
