# API Overview
- `StateTensor(GridShape)`
- `LocalHamiltonian.build()`
- `MultiTemporalEvolver.step(psi)`
- `resource.temporal_scaling(alpha)`
