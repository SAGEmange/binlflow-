# Examples
## Minimal Simulation
```bash
python examples/minimal_sim.py
```
