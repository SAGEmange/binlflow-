# BINLFOW
Quantum-inspired, *classically simulated* multi-temporal cloud ML framework.
> Prototype: not actual quantum computing.
