# Mathematical Foundation
Mirrors your spec: state tensor Ψ over (x,y,z,t₁,t₂,t₃,s), effective Hamiltonians,
Lindblad dissipators, inter-node Ĵ and V, and multi-physics couplings.
