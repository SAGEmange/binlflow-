import torch
from binlflow.states import NUM_STATES
from binlflow.tensor import GridShape, StateTensor
from binlflow.hamiltonian import LocalHamiltonian, Couplings
from binlflow.lindblad import LindbladPack
from binlflow.evolution import MultiTemporalEvolver
from binlflow.resource import optimal_load_balancing, temporal_scaling
from binlflow.metrics import coherence, multi_temporal_efficiency

device = "cpu"
shape = GridShape(X=4, Y=4, Z=2, T1=1, T2=1, T3=1)
psi_obj = StateTensor(shape, device=device).normalize()
psi = psi_obj.psi

torch.manual_seed(0)
psi = (torch.randn_like(psi) + 1j*torch.randn_like(psi))*0.1
psi = psi / torch.sqrt(torch.sum(torch.abs(psi)**2, dim=-1, keepdim=True))

H_local = LocalHamiltonian(diag_strength=0.8, mix_strength=0.05).build(NUM_STATES, device=device)
coup = Couplings(J=0.03, V=0.005)
lind = LindbladPack(dephase_rate=0.01, damp_rate=0.02)

evolver = MultiTemporalEvolver(H_local=H_local, couplings=coup, lindblad=lind)

steps = 10
for t in range(steps):
    psi = evolver.step(psi, dt1=0.02, dt2=0.03, dt3=0.05)
    psi = psi / torch.sqrt(torch.sum(torch.abs(psi)**2, dim=-1, keepdim=True) + 1e-9)
    if t % 5 == 0:
        rho_total = psi
        rho_ideal = psi.conj()
        coh = float(coherence(rho_total, rho_ideal))
        cost = float(optimal_load_balancing(psi))
        R = float(temporal_scaling(psi).mean())
        eff = float(multi_temporal_efficiency(work=R, energy=1.0))
        print(f"t={t:02d}: coherence={coh:.4f} cost={cost:.4f} R~{R:.4f} eff~{eff:.4f}")

print("Done.")
