# BINLFOW — Quantum-Inspired Cloud ML Framework (Prototype)

Classical simulation of your BINLFOW spec using PyTorch complex tensors.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python examples/minimal_sim.py
```
