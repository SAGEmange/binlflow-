import torch

def maxwell_binlflow_coupling(E, B, alpha, mu0=1.0, eps0=1.0, dt=1e-2):
    prob = torch.real(alpha.conj()*alpha)
    prob_sum = torch.clamp(prob.sum(dim=-1, keepdim=True), min=1e-9)
    weight = prob / prob_sum
    scale = weight.mean(dim=-1, keepdim=True)

    dE = - (B) - mu0 * scale
    dB = (E) + mu0*eps0 * scale
    E = E + dt * dE
    B = B + dt * dB
    return E, B
