BINLFOW_STATES = ["F","S","L","P","T"]
STATE_TO_IDX = {s:i for i,s in enumerate(BINLFOW_STATES)}
NUM_STATES = len(BINLFOW_STATES)

def state_index(s: str):
    return STATE_TO_IDX[s]
