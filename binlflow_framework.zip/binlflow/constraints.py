import torch

def check_constraints(psi, grad=None, bandwidth_limit=1e3, vmax=1e3, energy=None, E_budget=1e6):
    ok = True
    msgs = []
    if grad is not None:
        bw = torch.linalg.norm(grad).item()
        if bw > bandwidth_limit:
            ok = False
            msgs.append(f"Bandwidth {bw:.2f} exceeds limit {bandwidth_limit}")
    if energy is not None and energy > E_budget:
        ok = False
        msgs.append(f"Energy {energy:.2f} exceeds budget {E_budget}")
    return ok, msgs
