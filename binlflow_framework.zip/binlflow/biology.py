import torch

def lotka_volterra(N, alpha, r=0.1, K_base=100.0, alpha_ij=0.01, dt=1e-2):
    prob = torch.real(alpha.conj()*alpha)
    K = K_base * (1.0 + 0.5*prob[...,0] - 0.3*prob[...,1])
    dN = r*N*(1 - N/torch.clamp(K, min=1e-6)) - alpha_ij*(N**2)/torch.clamp(K, min=1e-6)
    return N + dt*dN
